Put your songs, charts and events here, it should look like this:

assets/songs/your-song-name-here/
---- ./Inst.ogg
---- ./Voices.ogg
---- ./song-name-hard.json
---- ./events.json
---- ./script.lua