Put your sounds here!
(To be more specific, game over music (the beginning, loop and end), cutscene music, etc.)
Said music can also be played through Lua, using playSound.